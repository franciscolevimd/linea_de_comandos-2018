#include "cosmic_protector.hpp"

SmallAsteroid::SmallAsteroid() :
   Asteroid(10, RES_SMALLASTEROID)
{
   points = 10;
}

SmallAsteroid::~SmallAsteroid()
{
}

